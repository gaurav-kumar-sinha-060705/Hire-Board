import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_FILE = path.join(__dirname, "..", "data.json");

function load() {
  let data;
  if (!fs.existsSync(DB_FILE)) {
    data = { users: [], jobs: [], applications: [], conversations: [], messages: [], nextUserId: 1, nextJobId: 1, nextAppId: 1, nextConvId: 1, nextMsgId: 1 };
  } else {
    data = JSON.parse(fs.readFileSync(DB_FILE, "utf-8").replace(/^\uFEFF/, ""));
  }
  data.conversations ||= [];
  data.messages ||= [];
  data.nextConvId ||= 1;
  data.nextMsgId ||= 1;
  for (const a of data.applications) a.status ||= "applied";
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
  return data;
}

function save(data) {
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

let db = load();

export function getDb() {
  return db;
}

export function persist() {
  save(db);
}
