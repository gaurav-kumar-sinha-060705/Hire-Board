import { Router } from "express";
import { getDb, persist } from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = Router();

const RESUME_TYPES = {
  "application/pdf": "pdf",
  "application/msword": "doc",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
  "text/plain": "txt",
};
const MAX_RESUME_BYTES = 2 * 1024 * 1024;

function publicUser(user) {
  const { password, ...rest } = user;
  return rest;
}

function canViewSeeker(requester, target) {
  if (!target) return false;
  if (requester.id === target.id) return true;
  if (requester.role !== "recruiter") return false;
  const db = getDb();
  return db.jobs.some(
    (j) =>
      j.recruiterId === requester.id &&
      db.applications.some((a) => a.jobId === j.id && a.seekerId === target.id)
  );
}

function dataUrlBytes(dataUrl) {
  const comma = dataUrl.indexOf(",");
  const b64 = comma === -1 ? dataUrl : dataUrl.slice(comma + 1);
  const pad = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
  return Math.floor((b64.length * 3) / 4) - pad;
}

function cleanSkills(input) {
  const list = Array.isArray(input)
    ? input
    : typeof input === "string"
      ? input.split(",")
      : [];
  return list
    .map((s) => String(s).trim())
    .filter(Boolean)
    .slice(0, 20)
    .map((s) => s.slice(0, 40));
}

// PUT /api/users/me/profile — update own profile
router.put("/me/profile", authenticate, (req, res) => {
  const db = getDb();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "Account not found." });

  user.profile ||= {};
  const p = user.profile;
  const { headline, company, location, experience, bio, linkedin } = req.body;

  if (headline !== undefined) p.headline = String(headline).trim().slice(0, 120);
  if (company !== undefined) p.company = String(company).trim().slice(0, 120);
  if (location !== undefined) p.location = String(location).trim().slice(0, 120);
  if (experience !== undefined) p.experience = String(experience).trim().slice(0, 2000);
  if (bio !== undefined) p.bio = String(bio).trim().slice(0, 2000);
  if (linkedin !== undefined) {
    let value = String(linkedin).trim().slice(0, 200);
    if (value && !/^[a-z][a-z0-9+.-]*:\/\//i.test(value)) value = "https://" + value;
    p.linkedin = value;
  }
  if (req.body.skills !== undefined) p.skills = cleanSkills(req.body.skills);

  p.updatedAt = new Date().toISOString();
  persist();

  res.json({ user: publicUser(user) });
});

// POST /api/users/me/resume — upload/overwrite resume as a data URL
router.post("/me/resume", authenticate, (req, res) => {
  const db = getDb();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "Account not found." });

  const { name, mimeType, dataUrl } = req.body || {};
  if (!name || !mimeType || !dataUrl) {
    return res.status(400).json({ error: "Resume name, type, and data are required." });
  }
  if (!RESUME_TYPES[mimeType]) {
    return res.status(400).json({ error: "Resume must be a PDF, Word document, or text file." });
  }
  if (!dataUrl.startsWith(`data:${mimeType};base64,`)) {
    return res.status(400).json({ error: "Invalid file data." });
  }
  const size = dataUrlBytes(dataUrl);
  if (size === 0) return res.status(400).json({ error: "The file is empty." });
  if (size > MAX_RESUME_BYTES) {
    return res.status(400).json({ error: "Resume must be under 2 MB." });
  }

  user.profile ||= {};
  user.profile.resume = {
    name: String(name).slice(0, 120),
    mimeType,
    size,
    dataUrl,
    uploadedAt: new Date().toISOString(),
  };
  user.profile.updatedAt = user.profile.resume.uploadedAt;
  persist();

  res.json({ user: publicUser(user) });
});

// DELETE /api/users/me/resume — remove resume
router.delete("/me/resume", authenticate, (req, res) => {
  const db = getDb();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "Account not found." });
  if (!user.profile?.resume) return res.status(404).json({ error: "No resume on file." });

  delete user.profile.resume;
  user.profile.updatedAt = new Date().toISOString();
  persist();

  res.json({ user: publicUser(user) });
});

// GET /api/users/:id — view a profile (self, or recruiter with an application)
router.get("/:id", authenticate, (req, res) => {
  const db = getDb();
  const target = db.users.find((u) => u.id === Number(req.params.id));
  if (!target) return res.status(404).json({ error: "User not found." });
  if (!canViewSeeker(req.user, target)) {
    return res.status(403).json({ error: "You can only view candidates who applied to your postings." });
  }
  res.json({ user: publicUser(target) });
});

// GET /api/users/:id/resume — fetch a seeker's resume
router.get("/:id/resume", authenticate, (req, res) => {
  const db = getDb();
  const target = db.users.find((u) => u.id === Number(req.params.id));
  if (!target) return res.status(404).json({ error: "User not found." });
  if (!canViewSeeker(req.user, target)) {
    return res.status(403).json({ error: "You can only view candidates who applied to your postings." });
  }
  res.json({ resume: target.profile?.resume || null });
});

export default router;
