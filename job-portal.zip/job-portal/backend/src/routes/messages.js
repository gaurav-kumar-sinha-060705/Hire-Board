import { Router } from "express";
import { getDb, persist } from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = Router();

function otherParticipant(conv, userId) {
  const db = getDb();
  const otherId = conv.recruiterId === userId ? conv.seekerId : conv.recruiterId;
  return db.users.find((u) => u.id === otherId) || null;
}

function profileSummary(user) {
  const p = user?.profile || {};
  return {
    headline: p.headline || "",
    company: p.company || "",
    location: p.location || "",
    bio: p.bio || "",
  };
}

function withConversationMeta(conv, userId) {
  const db = getDb();
  const other = otherParticipant(conv, userId);
  const job = db.jobs.find((j) => j.id === conv.jobId);
  const messages = db.messages.filter((m) => m.conversationId === conv.id);
  const last = messages[messages.length - 1] || null;
  const unread = messages.filter((m) => m.senderId !== userId && !m.read).length;
  return {
    ...conv,
    other: other ? { id: other.id, name: other.name, role: other.role, profile: profileSummary(other) } : null,
    jobTitle: job?.title || "Deleted posting",
    jobCompany: job?.company || "",
    lastMessage: last ? last.body : "",
    lastMessageAt: last ? last.sentAt : conv.createdAt,
    unread,
  };
}

function belongsTo(conv, userId) {
  return conv.recruiterId === userId || conv.seekerId === userId;
}

function getConversation(jobId, userA, userB) {
  const db = getDb();
  return db.conversations.find(
    (c) =>
      c.jobId === jobId &&
      ((c.recruiterId === userA && c.seekerId === userB) ||
        (c.recruiterId === userB && c.seekerId === userA))
  );
}

function canMessagePair(sender, recipient, job) {
  if (!recipient || recipient.id === sender.id) return false;
  const db = getDb();
  const seekerId = sender.role === "seeker" ? sender.id : recipient.id;
  const applied = db.applications.some((a) => a.jobId === job.id && a.seekerId === seekerId);
  if (!applied) return false;
  if (sender.role === "recruiter") {
    return job.recruiterId === sender.id && recipient.role === "seeker";
  }
  if (sender.role === "seeker") {
    return job.recruiterId === recipient.id && recipient.role === "recruiter";
  }
  return false;
}

function markRead(conv, userId) {
  const db = getDb();
  let changed = false;
  for (const m of db.messages) {
    if (m.conversationId === conv.id && m.senderId !== userId && !m.read) {
      m.read = true;
      changed = true;
    }
  }
  return changed;
}

function sendMessage({ conversationId, jobId, recipientId, sender, body }) {
  const db = getDb();
  let conv = conversationId
    ? db.conversations.find((c) => c.id === Number(conversationId))
    : null;

  if (conv) {
    if (!belongsTo(conv, sender.id)) return { error: 403, message: "You aren't part of this conversation." };
  } else {
    const job = db.jobs.find((j) => j.id === Number(jobId));
    if (!job) return { error: 404, message: "Job not found." };
    const recipient = db.users.find((u) => u.id === Number(recipientId));
    if (!canMessagePair(sender, recipient, job)) {
      return { error: 403, message: "You can only message someone connected through a job you've applied to or posted." };
    }
    conv = getConversation(job.id, sender.id, recipient.id);
    if (!conv) {
      conv = {
        id: db.nextConvId++,
        jobId: job.id,
        recruiterId: job.recruiterId,
        seekerId: job.recruiterId === sender.id ? recipient.id : sender.id,
        createdAt: new Date().toISOString(),
      };
      db.conversations.push(conv);
    }
  }

  const message = {
    id: db.nextMsgId++,
    conversationId: conv.id,
    senderId: sender.id,
    body: body.trim(),
    sentAt: new Date().toISOString(),
    read: false,
  };
  db.messages.push(message);
  conv.lastMessageAt = message.sentAt;
  persist();

  return { conversationId: conv.id, message };
}

// GET /api/messages/conversations — current user's threads
router.get("/conversations", authenticate, (req, res) => {
  const db = getDb();
  const list = db.conversations
    .filter((c) => belongsTo(c, req.user.id))
    .sort((a, b) => new Date(b.lastMessageAt || b.createdAt) - new Date(a.lastMessageAt || a.createdAt))
    .map((c) => withConversationMeta(c, req.user.id));
  res.json({ conversations: list });
});

// GET /api/messages/thread?jobId=&with= — open or preview a pair's thread
router.get("/thread", authenticate, (req, res) => {
  const db = getDb();
  const jobId = Number(req.query.jobId);
  const withId = Number(req.query.with);
  const job = db.jobs.find((j) => j.id === jobId);
  if (!job) return res.status(404).json({ error: "Job not found." });

  const conv = getConversation(jobId, req.user.id, withId);
  if (!conv) {
    const recipient = db.users.find((u) => u.id === withId);
    return res.json({ conversation: null, job: { id: job.id, title: job.title, company: job.company }, recipient: recipient ? { id: recipient.id, name: recipient.name, role: recipient.role, profile: profileSummary(recipient) } : null });
  }
  if (!belongsTo(conv, req.user.id)) return res.status(403).json({ error: "This conversation isn't yours." });

  const changed = markRead(conv, req.user.id);
  if (changed) persist();

  const messages = db.messages
    .filter((m) => m.conversationId === conv.id)
    .sort((a, b) => new Date(a.sentAt) - new Date(b.sentAt));
  res.json({ conversation: withConversationMeta(conv, req.user.id), messages, job: { id: job.id, title: job.title, company: job.company } });
});

// GET /api/messages/:id — one conversation's messages
router.get("/:id", authenticate, (req, res) => {
  const db = getDb();
  const conv = db.conversations.find((c) => c.id === Number(req.params.id));
  if (!conv) return res.status(404).json({ error: "Conversation not found." });
  if (!belongsTo(conv, req.user.id)) return res.status(403).json({ error: "This conversation isn't yours." });

  const changed = markRead(conv, req.user.id);
  if (changed) persist();

  const messages = db.messages
    .filter((m) => m.conversationId === conv.id)
    .sort((a, b) => new Date(a.sentAt) - new Date(b.sentAt));
  res.json({ conversation: withConversationMeta(conv, req.user.id), messages });
});

// POST /api/messages — send a message (creates the conversation if needed)
router.post("/", authenticate, (req, res) => {
  const { conversationId, jobId, recipientId, body } = req.body;
  if (!body?.trim()) return res.status(400).json({ error: "Write a message first." });
  if (String(body).length > 5000) return res.status(400).json({ error: "Message must be under 5,000 characters." });

  const result = sendMessage({ conversationId, jobId, recipientId, sender: req.user, body });
  if (result.error) return res.status(result.error).json({ error: result.message });
  const db = getDb();
  const conv = db.conversations.find((c) => c.id === result.conversationId);
  res.status(201).json({ conversation: withConversationMeta(conv, req.user.id), message: result.message });
});

export default router;
