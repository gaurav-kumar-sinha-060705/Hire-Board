import { Router } from "express";
import { getDb, persist } from "../db.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const STATUSES = ["applied", "in-review", "shortlisted", "rejected", "accepted"];
const TYPES = ["Full-time", "Part-time", "Internship", "Contract"];
const MODES = ["On-site", "Remote", "Hybrid"];

function validateJob(body) {
  const { title, company, location, type, mode, salary, description, requirements } = body;
  if (!title?.trim() || !company?.trim() || !location?.trim() || !description?.trim()) {
    return { error: "Title, company, location, and description are required." };
  }
  if (String(title).trim().length > 120) return { error: "Title must be under 120 characters." };
  if (String(company).trim().length > 120) return { error: "Company must be under 120 characters." };
  if (String(location).trim().length > 120) return { error: "Location must be under 120 characters." };
  if (String(salary || "").trim().length > 60) return { error: "Salary must be under 60 characters." };
  if (String(description || "").trim().length > 20000) return { error: "Description must be under 20,000 characters." };
  if (String(requirements || "").trim().length > 20000) return { error: "Requirements must be under 20,000 characters." };
  if (type && !TYPES.includes(type)) return { error: `Type must be one of: ${TYPES.join(", ")}.` };
  if (mode && !MODES.includes(mode)) return { error: `Mode must be one of: ${MODES.join(", ")}.` };

  return {
    job: {
      title: String(title).trim(),
      company: String(company).trim(),
      location: String(location).trim(),
      type: type || "Full-time",
      mode: mode || "On-site",
      salary: String(salary || "").trim().slice(0, 60),
      description: String(description).trim(),
      requirements: String(requirements || "").trim(),
    },
  };
}

function withApplicantCount(job, db) {
  const count = db.applications.filter((a) => a.jobId === job.id).length;
  return { ...job, applicantCount: count };
}

// GET /api/jobs?q=search — public list, newest first
router.get("/", (req, res) => {
  const db = getDb();
  const q = (req.query.q || "").toLowerCase().trim();

  let jobs = [...db.jobs].sort((a, b) => b.id - a.id);
  if (q) {
    jobs = jobs.filter(
      (j) =>
        j.title.toLowerCase().includes(q) ||
        j.company.toLowerCase().includes(q) ||
        j.location.toLowerCase().includes(q)
    );
  }
  res.json({ jobs: jobs.map((j) => withApplicantCount(j, db)) });
});

// GET /api/jobs/mine — recruiter's own postings with applicant counts
router.get("/mine", authenticate, authorize("recruiter"), (req, res) => {
  const db = getDb();
  const jobs = db.jobs
    .filter((j) => j.recruiterId === req.user.id)
    .sort((a, b) => b.id - a.id)
    .map((j) => withApplicantCount(j, db));
  res.json({ jobs });
});

// GET /api/jobs/:id
router.get("/:id", (req, res) => {
  const db = getDb();
  const job = db.jobs.find((j) => j.id === Number(req.params.id));
  if (!job) return res.status(404).json({ error: "Job not found." });
  res.json({ job: withApplicantCount(job, db) });
});

// POST /api/jobs — recruiter creates a posting
router.post("/", authenticate, authorize("recruiter"), (req, res) => {
  const db = getDb();
  const result = validateJob(req.body);
  if (result.error) return res.status(400).json({ error: result.error });

  const job = {
    id: db.nextJobId++,
    recruiterId: req.user.id,
    recruiterName: req.user.name,
    ...result.job,
    postedAt: new Date().toISOString(),
  };
  db.jobs.push(job);
  persist();

  res.status(201).json({ job: withApplicantCount(job, db) });
});

// PUT /api/jobs/:id — recruiter edits their own posting
router.put("/:id", authenticate, authorize("recruiter"), (req, res) => {
  const db = getDb();
  const jobId = Number(req.params.id);
  const job = db.jobs.find((j) => j.id === jobId);
  if (!job) return res.status(404).json({ error: "Job not found." });
  if (job.recruiterId !== req.user.id) return res.status(403).json({ error: "This job isn't yours." });

  const result = validateJob(req.body);
  if (result.error) return res.status(400).json({ error: result.error });

  Object.assign(job, result.job);
  persist();

  res.json({ job: withApplicantCount(job, db) });
});

// DELETE /api/jobs/:id — recruiter removes their own posting
router.delete("/:id", authenticate, authorize("recruiter"), (req, res) => {
  const db = getDb();
  const jobId = Number(req.params.id);
  const job = db.jobs.find((j) => j.id === jobId);
  if (!job) return res.status(404).json({ error: "Job not found." });
  if (job.recruiterId !== req.user.id) return res.status(403).json({ error: "This job isn't yours." });

  db.jobs = db.jobs.filter((j) => j.id !== jobId);
  db.applications = db.applications.filter((a) => a.jobId !== jobId);
  const convIds = db.conversations.filter((c) => c.jobId === jobId).map((c) => c.id);
  db.conversations = db.conversations.filter((c) => c.jobId !== jobId);
  db.messages = db.messages.filter((m) => !convIds.includes(m.conversationId));
  persist();

  res.json({ job: withApplicantCount(job, db) });
});

// POST /api/jobs/:id/apply — seeker applies
router.post("/:id/apply", authenticate, authorize("seeker"), (req, res) => {
  const db = getDb();
  const jobId = Number(req.params.id);
  const job = db.jobs.find((j) => j.id === jobId);
  if (!job) return res.status(404).json({ error: "Job not found." });

  const { name, email, note } = req.body;
  if (!name?.trim() || !EMAIL_RE.test(email || "")) {
    return res.status(400).json({ error: "Enter your name and a valid email." });
  }
  if (String(name).trim().length > 120) return res.status(400).json({ error: "Name must be under 120 characters." });
  if (String(note || "").length > 2000) return res.status(400).json({ error: "Cover note must be under 2,000 characters." });

  const already = db.applications.some((a) => a.jobId === jobId && a.seekerId === req.user.id);
  if (already) return res.status(409).json({ error: "You already applied to this job." });

  const application = {
    id: db.nextAppId++,
    jobId,
    seekerId: req.user.id,
    name: name.trim(),
    email: email.trim(),
    note: (note || "").trim(),
    status: "applied",
    appliedAt: new Date().toISOString(),
  };
  db.applications.push(application);
  persist();

  res.status(201).json({ application });
});

// GET /api/jobs/:id/applicants — recruiter views applicants to their own job
router.get("/:id/applicants", authenticate, authorize("recruiter"), (req, res) => {
  const db = getDb();
  const jobId = Number(req.params.id);
  const job = db.jobs.find((j) => j.id === jobId);
  if (!job) return res.status(404).json({ error: "Job not found." });
  if (job.recruiterId !== req.user.id) return res.status(403).json({ error: "This job isn't yours." });

  const applicants = db.applications
    .filter((a) => a.jobId === jobId)
    .sort((a, b) => b.id - a.id)
    .map((a) => {
      const seeker = db.users.find((u) => u.id === a.seekerId);
      const profile = seeker?.profile || {};
      const resume = profile.resume
        ? { name: profile.resume.name, mimeType: profile.resume.mimeType, size: profile.resume.size, uploadedAt: profile.resume.uploadedAt }
        : null;
      return {
        ...a,
        seekerProfile: {
          headline: profile.headline || "",
          location: profile.location || "",
          skills: profile.skills || [],
          experience: profile.experience || "",
          bio: profile.bio || "",
          linkedin: profile.linkedin || "",
          resume,
        },
      };
    });
  res.json({ applicants });
});

// GET /api/jobs/mine/applied — seeker: which job ids they've applied to
router.get("/mine/applied", authenticate, authorize("seeker"), (req, res) => {
  const db = getDb();
  const jobIds = db.applications.filter((a) => a.seekerId === req.user.id).map((a) => a.jobId);
  res.json({ jobIds });
});

// GET /api/jobs/applications/mine — seeker: their applications with job info
router.get("/applications/mine", authenticate, authorize("seeker"), (req, res) => {
  const db = getDb();
  const applications = db.applications
    .filter((a) => a.seekerId === req.user.id)
    .sort((a, b) => b.id - a.id)
    .map((a) => {
      const job = db.jobs.find((j) => j.id === a.jobId);
      return {
        ...a,
        job: job
          ? { id: job.id, title: job.title, company: job.company, location: job.location, recruiterId: job.recruiterId }
          : null,
      };
    });
  res.json({ applications });
});

// PATCH /api/jobs/:jobId/applicants/:appId — recruiter updates an applicant's status
router.patch("/:jobId/applicants/:appId", authenticate, authorize("recruiter"), (req, res) => {
  const db = getDb();
  const jobId = Number(req.params.jobId);
  const appId = Number(req.params.appId);
  const job = db.jobs.find((j) => j.id === jobId);
  if (!job) return res.status(404).json({ error: "Job not found." });
  if (job.recruiterId !== req.user.id) return res.status(403).json({ error: "This job isn't yours." });

  const application = db.applications.find((a) => a.id === appId && a.jobId === jobId);
  if (!application) return res.status(404).json({ error: "Application not found." });

  const status = (req.body.status || "").toLowerCase();
  if (!STATUSES.includes(status)) {
    return res.status(400).json({ error: `Status must be one of: ${STATUSES.join(", ")}.` });
  }

  application.status = status;
  persist();

  res.json({ application });
});

export default router;
