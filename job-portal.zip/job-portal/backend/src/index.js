import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import authRoutes from "./routes/auth.js";
import jobRoutes from "./routes/jobs.js";
import userRoutes from "./routes/users.js";
import messageRoutes from "./routes/messages.js";

dotenv.config();

if (process.env.NODE_ENV === "production") {
  const secret = process.env.JWT_SECRET || "";
  if (!secret || secret === "change-this-to-a-long-random-string" || secret.length < 16) {
    console.error("JWT_SECRET must be set to a strong value (16+ characters) in production.");
    process.exit(1);
  }
}

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth", authRoutes);
app.use("/api/jobs", jobRoutes);
app.use("/api/users", userRoutes);
app.use("/api/messages", messageRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true }));

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server." });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Job portal API running on http://localhost:${PORT}`));
