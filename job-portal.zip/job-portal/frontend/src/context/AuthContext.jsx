import { createContext, useContext, useEffect, useState } from "react";
import { api } from "../api.js";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem("hb_token") || null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (!token) {
      setReady(true);
      return;
    }
    api
      .me(token)
      .then((data) => setUser(data.user))
      .catch(() => {
        setToken(null);
        localStorage.removeItem("hb_token");
      })
      .finally(() => setReady(true));
  }, [token]);

  function onAuthed({ token: t, user: u }) {
    localStorage.setItem("hb_token", t);
    setToken(t);
    setUser(u);
  }

  async function register(payload) {
    const data = await api.register(payload);
    onAuthed(data);
    return data.user;
  }

  async function login(payload) {
    const data = await api.login(payload);
    onAuthed(data);
    return data.user;
  }

  async function refreshUser() {
    if (!token) return null;
    const data = await api.me(token);
    setUser(data.user);
    return data.user;
  }

  function logout() {
    localStorage.removeItem("hb_token");
    setToken(null);
    setUser(null);
  }

  return (
    <AuthContext.Provider value={{ user, token, ready, register, login, refreshUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
