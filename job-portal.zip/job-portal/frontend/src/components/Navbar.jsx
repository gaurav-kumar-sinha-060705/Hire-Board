import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function Navbar() {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  function isActive(path) {
    return location.pathname === path ? "nav-link active" : "nav-link";
  }

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <div className="nav">
      <div className="nav-inner">
        <Link to="/" className="nav-brand">Hire Board</Link>
        <div className="nav-links">
          <Link className={isActive("/")} to="/">Browse jobs</Link>
          {user?.role === "recruiter" && (
            <>
              <Link className={isActive("/post")} to="/post">Post a job</Link>
              <Link className={isActive("/my-jobs")} to="/my-jobs">My postings</Link>
            </>
          )}
          {user?.role === "seeker" && (
            <Link className={isActive("/applications")} to="/applications">My applications</Link>
          )}
          {user && (
            <Link className={isActive("/profile")} to="/profile">Profile</Link>
          )}
          {user ? (
            <>
              <Link className={isActive("/messages")} to="/messages">Messages</Link>
              <span className="nav-user">{user.name}</span>
              <button className="btn small outline" onClick={handleLogout}>Sign out</button>
            </>
          ) : (
            <Link className="nav-link" to="/login">Sign in</Link>
          )}
        </div>
      </div>
    </div>
  );
}
