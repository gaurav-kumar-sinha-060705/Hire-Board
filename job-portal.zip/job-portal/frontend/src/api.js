const BASE = "/api";

async function request(path, { method = "GET", body, token } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(BASE + path, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}

export const api = {
  register: (payload) => request("/auth/register", { method: "POST", body: payload }),
  login: (payload) => request("/auth/login", { method: "POST", body: payload }),
  me: (token) => request("/auth/me", { token }),

  listJobs: (q) => request(`/jobs${q ? `?q=${encodeURIComponent(q)}` : ""}`),
  getJob: (jobId) => request(`/jobs/${jobId}`),
  myJobs: (token) => request("/jobs/mine", { token }),
  postJob: (payload, token) => request("/jobs", { method: "POST", body: payload, token }),
  updateJob: (jobId, payload, token) => request(`/jobs/${jobId}`, { method: "PUT", body: payload, token }),
  deleteJob: (jobId, token) => request(`/jobs/${jobId}`, { method: "DELETE", token }),
  applyToJob: (jobId, payload, token) => request(`/jobs/${jobId}/apply`, { method: "POST", body: payload, token }),
  applicants: (jobId, token) => request(`/jobs/${jobId}/applicants`, { token }),
  appliedJobIds: (token) => request("/jobs/mine/applied", { token }),
  updateApplicationStatus: (jobId, appId, status, token) =>
    request(`/jobs/${jobId}/applicants/${appId}`, { method: "PATCH", body: { status }, token }),
  myApplications: (token) => request("/jobs/applications/mine", { token }),

  myConversations: (token) => request("/messages/conversations", { token }),
  openThread: (jobId, withId, token) => request(`/messages/thread?jobId=${jobId}&with=${withId}`, { token }),
  conversationMessages: (convId, token) => request(`/messages/${convId}`, { token }),
  sendMessage: (payload, token) => request("/messages", { method: "POST", body: payload, token }),

  getProfile: (userId, token) => request(`/users/${userId}`, { token }),
  updateProfile: (payload, token) => request("/users/me/profile", { method: "PUT", body: payload, token }),
  uploadResume: (payload, token) => request("/users/me/resume", { method: "POST", body: payload, token }),
  removeResume: (token) => request("/users/me/resume", { method: "DELETE", token }),
  getResume: (userId, token) => request(`/users/${userId}/resume`, { token }),
};
