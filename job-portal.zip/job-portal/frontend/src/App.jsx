import { Routes, Route, Navigate } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import { useAuth } from "./context/AuthContext.jsx";
import Login from "./pages/Login.jsx";
import Register from "./pages/Register.jsx";
import BrowseJobs from "./pages/BrowseJobs.jsx";
import JobDetail from "./pages/JobDetail.jsx";
import PostJob from "./pages/PostJob.jsx";
import MyJobs from "./pages/MyJobs.jsx";
import MyApplications from "./pages/MyApplications.jsx";
import Profile from "./pages/Profile.jsx";
import Messages from "./pages/Messages.jsx";

function RequireRole({ role, children }) {
  const { user, ready } = useAuth();
  if (!ready) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (role && user.role !== role) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { ready } = useAuth();
  if (!ready) return null;

  return (
    <>
      <Navbar />
      <div className="shell">
        <Routes>
          <Route path="/" element={<BrowseJobs />} />
          <Route path="/jobs/:id" element={<JobDetail />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route
            path="/post"
            element={
              <RequireRole role="recruiter">
                <PostJob />
              </RequireRole>
            }
          />
          <Route
            path="/my-jobs"
            element={
              <RequireRole role="recruiter">
                <MyJobs />
              </RequireRole>
            }
          />
          <Route
            path="/applications"
            element={
              <RequireRole role="seeker">
                <MyApplications />
              </RequireRole>
            }
          />
          <Route
            path="/profile"
            element={
              <RequireRole>
                <Profile />
              </RequireRole>
            }
          />
          <Route
            path="/messages"
            element={
              <RequireRole>
                <Messages />
              </RequireRole>
            }
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </div>
    </>
  );
}
