import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../context/AuthContext.jsx";
import ApplyModal from "../components/ApplyModal.jsx";
import { statusLabel, statusClass } from "../status.js";

function jobTicketId(id) {
  return "JOB-" + String(id).padStart(4, "0");
}

export default function JobDetail() {
  const { id } = useParams();
  const { user, token } = useAuth();
  const navigate = useNavigate();
  const [job, setJob] = useState(null);
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applyOpen, setApplyOpen] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => {
    setLoading(true);
    api.getJob(id).then((d) => setJob(d.job)).catch(() => setJob(null)).finally(() => setLoading(false));
  }, [id]);

  useEffect(() => {
    if (user?.role === "seeker" && token) {
      api.myApplications(token).then((d) => {
        const app = d.applications.find((a) => a.jobId === Number(id));
        setStatus(app ? app.status : null);
      }).catch(() => {});
    } else {
      setStatus(null);
    }
  }, [user, token, id]);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(""), 2600);
  }

  function handleApplyClick() {
    if (!user) {
      navigate("/login");
      return;
    }
    if (user.role !== "seeker") {
      showToast("Sign in as a job seeker to apply.");
      return;
    }
    setApplyOpen(true);
  }

  async function submitApplication(payload) {
    await api.applyToJob(job.id, payload, token);
    setStatus("applied");
    setApplyOpen(false);
    showToast("Application submitted.");
  }

  if (loading) return null;

  if (!job) {
    return (
      <div className="empty-state">
        <h3>Job not found</h3>
        <p><button className="btn link" onClick={() => navigate("/")}>Back to browse</button></p>
      </div>
    );
  }

  const isOwner = user?.role === "recruiter" && job.recruiterId === user.id;

  return (
    <div>
      <div className="eyebrow"><button className="btn link" onClick={() => navigate(-1)}>← Back</button></div>
      <div className="job-head" style={{ marginTop: 12 }}>
        <div>
          <h1 className="page-title" style={{ fontSize: 26 }}>{job.title}</h1>
          <div className="job-company">{job.company} · {job.location}</div>
        </div>
        <div className="job-id">{jobTicketId(job.id)}</div>
      </div>

      <div className="job-tags">
        <span className="tag dark">{job.type}</span>
        <span className="tag">{job.mode}</span>
        {job.salary && <span className="tag">{job.salary}</span>}
      </div>

      <div className="job-foot">
        <span className="job-meta">Posted {new Date(job.postedAt).toLocaleDateString()}</span>
        {isOwner && <span className="job-meta">{job.applicantCount} applicant{job.applicantCount === 1 ? "" : "s"}</span>}
      </div>

      <div className="job-detail-section">
        <div className="profile-label">Description</div>
        <p className="job-desc">{job.description}</p>
      </div>

      {job.requirements && (
        <div className="job-detail-section">
          <div className="profile-label">Requirements</div>
          <p className="job-desc">{job.requirements}</p>
        </div>
      )}

      <div className="job-foot" style={{ marginTop: 8 }}>
        <div className="job-actions">
          {status && (
            <>
              <span className={statusClass(status)}>{statusLabel(status)}</span>
              <button className="btn small outline" onClick={() => navigate(`/messages?job=${job.id}&with=${job.recruiterId}`)}>
                Message recruiter
              </button>
            </>
          )}
          {!status && !isOwner && (
            <button className="btn" onClick={handleApplyClick}>Apply now</button>
          )}
        </div>
      </div>

      {applyOpen && (
        <ApplyModal
          job={job}
          defaultName={user?.name}
          defaultEmail={user?.email}
          onClose={() => setApplyOpen(false)}
          onSubmit={submitApplication}
        />
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
