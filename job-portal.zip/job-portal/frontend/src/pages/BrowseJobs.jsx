import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../context/AuthContext.jsx";
import ApplyModal from "../components/ApplyModal.jsx";
import { statusLabel, statusClass } from "../status.js";

function jobTicketId(id) {
  return "JOB-" + String(id).padStart(4, "0");
}

export default function BrowseJobs() {
  const { user, token } = useAuth();
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [query, setQuery] = useState("");
  const [statusByJob, setStatusByJob] = useState({});
  const [applyTarget, setApplyTarget] = useState(null);
  const [toast, setToast] = useState("");
  const [loading, setLoading] = useState(true);

  async function loadJobs(q) {
    const data = await api.listJobs(q);
    setJobs(data.jobs);
  }

  useEffect(() => {
    setLoading(true);
    loadJobs("").finally(() => setLoading(false));
    if (user?.role === "seeker" && token) {
      api.myApplications(token).then((d) => {
        const map = {};
        for (const a of d.applications) map[a.jobId] = a.status;
        setStatusByJob(map);
      });
    }
  }, [user, token]);

  useEffect(() => {
    const t = setTimeout(() => loadJobs(query), 250);
    return () => clearTimeout(t);
  }, [query]);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(""), 2600);
  }

  function handleApplyClick(job) {
    if (!user) {
      navigate("/login");
      return;
    }
    if (user.role !== "seeker") {
      showToast("Sign in as a job seeker to apply.");
      return;
    }
    setApplyTarget(job);
  }

  async function submitApplication(payload) {
    await api.applyToJob(applyTarget.id, payload, token);
    setStatusByJob((m) => ({ ...m, [applyTarget.id]: "applied" }));
    setApplyTarget(null);
    showToast("Application submitted.");
  }

  return (
    <div>
      <div className="eyebrow">Open roles</div>
      <h1 className="page-title">Browse jobs</h1>
      <p className="page-sub">Search current postings and apply directly.</p>

      <div className="search-row">
        <input
          type="text"
          placeholder="Search by title, company, or location"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {!loading && jobs.length === 0 && (
        <div className="empty-state">
          <h3>No jobs found</h3>
          <p>{query ? "Try a different search." : "Check back soon, or post the first role."}</p>
        </div>
      )}

      {jobs.map((job) => {
        const status = statusByJob[job.id];
        const applied = Boolean(status);
        return (
          <div className="job" key={job.id}>
            <div className="job-head">
              <div>
                <h2 className="job-title"><Link className="job-title-link" to={`/jobs/${job.id}`}>{job.title}</Link></h2>
                <div className="job-company">{job.company} · {job.location}</div>
              </div>
              <div className="job-id">{jobTicketId(job.id)}</div>
            </div>
            <div className="job-tags">
              <span className="tag dark">{job.type}</span>
              <span className="tag">{job.mode}</span>
              {job.salary && <span className="tag">{job.salary}</span>}
            </div>
            <p className="job-desc">
              {job.description.length > 220 ? job.description.slice(0, 220).trimEnd() + "…" : job.description}
              {job.description.length > 220 && (
                <Link className="btn link" to={`/jobs/${job.id}`} style={{ marginLeft: 6 }}>Read more</Link>
              )}
            </p>
            <div className="job-foot">
              <span className="job-meta">Posted {new Date(job.postedAt).toLocaleDateString()}</span>
              <div className="job-actions">
                {applied && (
                  <>
                    <span className={statusClass(status)}>{statusLabel(status)}</span>
                    <button className="btn small outline" onClick={() => navigate(`/messages?job=${job.id}&with=${job.recruiterId}`)}>
                      Message recruiter
                    </button>
                  </>
                )}
                {!applied && (
                  <button className="btn small" onClick={() => handleApplyClick(job)}>Apply now</button>
                )}
              </div>
            </div>
          </div>
        );
      })}

      {applyTarget && (
        <ApplyModal
          job={applyTarget}
          defaultName={user?.name}
          defaultEmail={user?.email}
          onClose={() => setApplyTarget(null)}
          onSubmit={submitApplication}
        />
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}
