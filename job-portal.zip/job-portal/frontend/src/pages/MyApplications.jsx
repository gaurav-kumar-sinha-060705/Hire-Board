import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useAuth } from "../context/AuthContext.jsx";
import { statusLabel, statusClass } from "../status.js";

function jobTicketId(id) {
  return "JOB-" + String(id).padStart(4, "0");
}

export default function MyApplications() {
  const { token } = useAuth();
  const navigate = useNavigate();
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.myApplications(token)
      .then((d) => setApps(d.applications))
      .finally(() => setLoading(false));
  }, [token]);

  if (loading) return null;

  return (
    <div>
      <div className="eyebrow">Dashboard</div>
      <h1 className="page-title">My applications</h1>
      <p className="page-sub">Track the status of every role you've applied to.</p>

      {apps.length === 0 && (
        <div className="empty-state">
          <h3>No applications yet</h3>
          <p><button className="btn link" onClick={() => navigate("/")}>Browse open jobs</button></p>
        </div>
      )}

      {apps.map((a) => (
        <div className="job" key={a.id}>
          <div className="job-head">
            <div>
              <h2 className="job-title">{a.job ? a.job.title : "Deleted posting"}</h2>
              <div className="job-company">
                {a.job ? `${a.job.company} · ${a.job.location}` : "This posting is no longer available"}
              </div>
            </div>
            <div className="job-id">{a.job ? jobTicketId(a.job.id) : "—"}</div>
          </div>
          <div className="job-foot">
            <span className="job-meta">Applied {new Date(a.appliedAt).toLocaleDateString()}</span>
            <div className="job-actions">
              <span className={statusClass(a.status)}>{statusLabel(a.status)}</span>
              {a.job && (
                <button
                  className="btn small outline"
                  onClick={() => navigate(`/messages?job=${a.job.id}&with=${a.job.recruiterId}`)}
                >Message recruiter</button>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
