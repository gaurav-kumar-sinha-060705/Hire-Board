# Hire Board — Job Apply Portal (MVP)

A full-stack job portal: recruiters post jobs, seekers browse and apply.
Black-and-white, formal visual theme. Node/Express backend with a simple
JSON file store, React (Vite) frontend.

## What's included

- Email/password sign-up and login with two account types: **recruiter** and **seeker**
- Recruiters: post jobs, view postings, edit/delete them, see applicants per job, and update each applicant's status
- Application statuses: **applied → in review → shortlisted → rejected / accepted** (seekers track them on a "My applications" page)
- Seekers: search/browse jobs, open a full job detail page, apply with name, email, and a cover note
- Seeker profiles: headline, skills, experience, bio, LinkedIn — plus a resume upload (PDF/Word/TXT, up to 2 MB) recruiters can view
- Recruiter profiles: headline, company, bio, LinkedIn — shown to seekers in conversations
- Recruiter ↔ seeker messaging per job with unread counts and auto-refresh
- JWT-based auth, passwords hashed with bcrypt; login/register rate-limited; input limits enforced
- Data persists to `backend/data.json` (no external database to install)

## Requirements

- Node.js 18 or later (check with `node -v`)
- npm (comes with Node)

## Setup — step by step

### 1. Unzip and open a terminal in the project folder

```
cd job-portal
```

### 2. Set up the backend

```
cd backend
npm install
cp .env.example .env
```

Open `.env` and set `JWT_SECRET` to any long random string (used to sign login tokens).
In production (`NODE_ENV=production`) the server refuses to start without a strong `JWT_SECRET` (16+ characters).

Start the API:

```
npm run dev
```

You should see:

```
Job portal API running on http://localhost:5000
```

Leave this running. It creates `backend/data.json` on first run to store users, jobs, and applications.

### 3. Set up the frontend (in a new terminal)

```
cd frontend
npm install
npm run dev
```

Vite will print a local URL, typically:

```
http://localhost:5173
```

Open that in your browser. The frontend dev server proxies `/api` calls to the backend on port 5000, so both must be running.

### 4. Try it out

1. Go to **Register**, create a **recruiter** account, and post a job.
2. Open an incognito window (or sign out), register as a **job seeker**, and apply to that job.
3. Sign back in as the recruiter and open **My postings → View applicants** to see the application.

## Project structure

```
job-portal/
  backend/
    src/
      index.js          Express app entry point
      db.js              JSON file read/write helpers
      middleware/auth.js JWT verification + role checks
      middleware/rateLimit.js  in-memory rate limiter
      routes/auth.js     register, login, me
      routes/jobs.js     list, detail, post, edit, delete, apply, applicants, status
      routes/users.js    profiles + resume upload/removal
      routes/messages.js conversations + threads
    data.json            created on first run — your data lives here
  frontend/
    src/
      pages/              Login, Register, BrowseJobs, JobDetail, PostJob, MyJobs, MyApplications, Messages, Profile
      components/          Navbar, ApplyModal
      context/AuthContext.jsx
      api.js               fetch wrapper for the backend
      styles.css           black/white formal theme
```

## Notes on the data store

For an MVP, `backend/data.json` stands in for a real database — it's easy
to read, needs no setup, and survives server restarts. To move to
Postgres or MongoDB later, only `backend/src/db.js` and the queries in
`routes/*.js` need to change; the API shape and frontend stay the same.

## Deploying later

- Backend: any Node host (Render, Railway, Fly.io). Set `JWT_SECRET` as an environment variable there too.
- Frontend: `npm run build` in `frontend/` produces a static `dist/` folder deployable to Vercel, Netlify, or any static host. Point its API calls at your deployed backend URL instead of the Vite proxy.
